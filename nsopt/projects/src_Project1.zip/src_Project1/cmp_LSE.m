clear all
close all
clc

addpath toolbox
set(groot,'defaultLineLineWidth',1.5);
%% set-up        
n = 5e1;

A = 2*eye(n) - diag(ones(n-1,1), -1) - diag(ones(n-1,1), 1);

x_ob = randn(n, 1);
b_ob = A *x_ob;
b = b_ob + 1e-1*randn(n, 1);
b = 0*b;

% para.beta = 1/norm(A)^2;
para.gamma = 1.0 /norm(A)^2;
para.maxits = 1e6 + 1;
para.tol = 1e-16;
para.n = n;

para.mu = 0;

proxJ = @(x, t) x;
gradF = @(x) (A')*(A*x - b);
objF = @(x) norm(A*x-b)^2 /2;

para.x0 = 1e4*ones(n, 1);

para.verbose = 1;
%% compute strong convexity     
gamma = para.gamma;

v = svd((A')*A);
alpha = min(v);

eta = 1 - gamma*alpha;
a_opt = (1-sqrt(1-eta))/(1+sqrt(1-eta));
%% Optimal scheme 
fprintf(sprintf('performing optimal scheme...\n'));

p = 1;
q = 1;
r = 4*(1-p) ...
    + 4*p*(1-sqrt(gamma*alpha))/(1+sqrt(gamma*alpha)) ...
    + 4*gamma*alpha*(p^2-q)/((1+sqrt(gamma*alpha))^2);

[xsol, ~, ~, ~, ~] = func_FISTA(r, para, proxJ,gradF, objF, 0);
xsol = 0*xsol;

[x, its, dk, ek, fk] = func_FISTA(r, para, proxJ,gradF, objF, xsol);

fprintf('\n');
%% Gradient Descent 
fprintf(sprintf('performing Gradient Descent...\n'));

r = 0;

[x1, its1, dk1, ek1, fk1] = func_FISTA(r, para, proxJ,gradF, objF, xsol);

fprintf('\n');
%% inertial Gradient Descent 
fprintf(sprintf('performing Gradient Descent...\n'));

r = 3;

[x2, its2, dk2, ek2, fk2] = func_FISTA(r, para, proxJ,gradF, objF, xsol);

fprintf('\n');
%% FISTA, original 
fprintf(sprintf('performing original FISTA...\n'));

r = 4;

[x3, its3, dk3, ek3, fk3] = func_FISTA(r, para, proxJ,gradF, objF, xsol);

fprintf('\n');
%% Restarting FISTA     
fprintf(sprintf('performing restarting FISTA...\n'));

r = 4; 

[x4, its4, dk4, ek4, fk4] = func_Restart_FISTA(r, para, proxJ,gradF, objF, xsol);

fprintf('\n');
%% color map   
hh = parula;
%% plot Phi(x_{k}) - Phi(x*)    
min_f = min([min(fk1), min(fk2), min(fk3), min(fk4)]);
linewidth = 1;

axesFontSize = 8;
labelFontSize = 8;
legendFontSize = 8;

resolution = 300; % output resolution
output_size = 300 *[10, 8]; % output size

%%%%%% relative error

figure(103), clf;
set(0,'DefaultAxesFontSize', axesFontSize);
set(gcf,'paperunits','centimeters','paperposition',[-0.1 -0.0 output_size/resolution]);
set(gcf,'papersize',output_size/resolution-[0.85 0.4]);

pf = semilogy(fk-min_f, 'r', 'LineWidth',linewidth);
hold on,

p1f = semilogy(fk1-min_f, 'color', hh(51,:), 'LineWidth',linewidth);

p2f = semilogy(fk2-min_f, 'color', hh(21,:), 'LineWidth',linewidth);

p3f = semilogy(fk3-min_f, 'color', hh(41,:), 'LineWidth',linewidth);

p4f = semilogy(fk4-min_f, 'k', 'LineWidth',linewidth);


uistack(p3f, 'bottom');

grid on;
ax = gca;
ax.GridLineStyle = '--';

axis([1, 10*its4, 1e-14, 2*max(fk1)]);
ytick = [1e-14, 1e-10, 1e-6, 1e-2, 1e2, 1e6];
set(gca, 'yTick', ytick);

ylb = ylabel({'$\Phi(x_{k})-\Phi(x^\star)$'}, 'FontSize', labelFontSize,...
    'FontAngle', 'normal', 'Interpreter', 'latex');
set(ylb, 'Units', 'Normalized', 'Position', [-0.1, 0.5, 0]);
xlb = xlabel({'\vspace{-1.0mm}';'$k$'}, 'FontSize', labelFontSize,...
    'FontAngle', 'normal', 'Interpreter', 'latex');
set(xlb, 'Units', 'Normalized', 'Position', [1/2, -0.075, 0]);


lg = legend([pf, p1f, p2f, p3f, p4f], ...
    'Optimal scheme', 'Gradient descent',...
    'Inertial gradient descent',...
    'FISTA', 'Restarting FISTA');
set(lg,'FontSize', legendFontSize);
% set(lg, 'Location', 'southeast');
% set(lg, 'Interpreter', 'latex');
legend('boxoff');

filename = ['results', filesep, sprintf('cmp-lse-fk.pdf')];
print(filename, '-dpdf');
filename = ['results', filesep, sprintf('cmp-lse-fk.png')];
print(filename, '-dpng');


