clear all
close all
clc

addpath data
addpath toolbox
set(groot,'defaultLineLineWidth',1.5);
%% load and scale data
load('australian_label.mat');
load('australian_sample.mat');

h = full(h);
% rescale the data
for j=1:size(h,2)
    h(:,j) = rescale(h(:,j), -1, 1);
end
%% parameters
[m, n] = size(h);

para.m = m;
para.n = n;

para.W = h;
para.y = l;

para.mu = 1e-2;

para.tol = 1e-15; % stopping criterion
para.maxits = 1e5; % max # of iteration

para.beta = m/norm(para.W)^2;
para.gamma = para.beta;

gradF = @(x) h'*(h*x - l) /m;% + para.mu* x;
proxJ = @(x, t) wthresh(x, 's', t);
objPhi = @(x) para.mu*sum(abs(x)) + 1/2/m*norm(h*x(:)-l)^2;


para.x0 = zeros(n, 1);

para.verbose = 1;
%% find optimal solution     
fprintf(sprintf('performing inertial PG...\n'));

r = 2; % inertial Forward--Backward

[xsol, ~, ~, ~, ~] = func_FISTA(r, para, proxJ,gradF, objPhi, 0);

fprintf('\n');
%% proximal gradient     
fprintf(sprintf('performing proximal gradient...\n'));

r = 0; % no inertial

[x1, its1, dk1, ek1, fk1] = func_FISTA(r, para, proxJ,gradF, objPhi, xsol);

fprintf('\n');
%% inertial proximal gradient     
fprintf(sprintf('performing inertial PG...\n'));

r = 2; % inertial parameter a = 1/2

[x2, its2, dk2, ek2, fk2] = func_FISTA(r, para, proxJ,gradF, objPhi, xsol);

fprintf('\n');
%% FISTA 
fprintf(sprintf('performing FISTA...\n'));

r = 4; % original FISTA

[x3, its3, dk3, ek3, fk3] = func_FISTA(r, para, proxJ,gradF, objPhi, xsol);

fprintf('\n');
%% Restarting FISTA     
fprintf(sprintf('performing restarting FISTA...\n'));

r = 4; % restarting FISTA

[x4, its4, dk4, ek4, fk4] = func_Restart_FISTA(r, para, proxJ,gradF, objPhi, xsol);

fprintf('\n');
%% color map   
hh = parula;
%% distance error ||x_{k}-x^\star||  
linewidth = 1;

axesFontSize = 8;
labelFontSize = 8;
legendFontSize = 8;

resolution = 300; % output resolution
output_size = 300 *[10, 8]; % output size

%%%%%% relative error

figure(101), clf;
set(0,'DefaultAxesFontSize', axesFontSize);
set(gcf,'paperunits','centimeters','paperposition',[-0.1 -0.0 output_size/resolution]);
set(gcf,'papersize',output_size/resolution-[0.85 0.4]);

p1d = semilogy(dk1, 'color', hh(46,:), 'LineWidth',linewidth);
hold on,

p2d = semilogy(dk2, 'color', hh(31,:), 'LineWidth',linewidth);

p3d = semilogy(dk3, 'color', hh(16,:), 'LineWidth',linewidth);

p4d = semilogy(dk4, 'color', hh(4,:), 'LineWidth',linewidth);

uistack(p1d, 'bottom');

grid on;
ax = gca;
ax.GridLineStyle = '--';

axis([1, its3, 1e-12, 2*max(dk1)]);
ytick = [1e-8, 1e-4, 1e-0, 1e4];
set(gca, 'yTick', ytick);

ylb = ylabel({'$\|x_{k}-x^\star\|$'}, 'FontSize', labelFontSize,...
    'FontAngle', 'normal', 'Interpreter', 'latex');
set(ylb, 'Units', 'Normalized', 'Position', [-0.1, 0.5, 0]);
xlb = xlabel({'\vspace{-1.0mm}';'$k$'}, 'FontSize', labelFontSize,...
    'FontAngle', 'normal', 'Interpreter', 'latex');
set(xlb, 'Units', 'Normalized', 'Position', [1/2, -0.075, 0]);


lg = legend([p1d, p2d, p3d, p4d], ...
    'Proximal gradient',...
    'Inertial proximal gradient',...
    'FISTA', 'Restarting FISTA');
set(lg,'FontSize', legendFontSize);
% set(lg, 'Interpreter', 'latex');
% set(lg, 'Location', 'best');
legend('boxoff');


filename = ['results', filesep, sprintf('cmp-LASSO-dk.pdf')];
print(filename, '-dpdf');
filename = ['results', filesep, sprintf('cmp-LASSO-dk.png')];
print(filename, '-dpng');