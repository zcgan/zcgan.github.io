clear all
close all
clc
%%
n = [128, 128];

r = 6; % rank
xl0 = rand(n(1),r)*diag(r:-1:1)*rand(r,n(2));
xl0 = xl0/max(abs(xl0(:))) *50;

xs0 = rand(n)*rand(n);
xs0 = xs0/max(abs(xs0(:))) *50;

ratio = 0.2; % sparsity
mask = proj_mask(xs0, ratio, 'p');
xs0 = xs0 .* mask;

f0 = xs0 + xl0;
%% parameters
para.mu1 = 1 /sqrt(max(n)); % weight for the sparse part
para.mu2 = 2; % weight for the low-rank part

para.beta = 1; % cocoercivity of the gradient

para.f = f;
para.n = n;

para.tol = 1e-10; % stopping criterion
para.maxits = 1e5; % max # of iteration

GradF = @(x) - ((f-x) - svt(f-x, para.mu2));
ProxJ = @(x, t) wthresh(x, 's', t);
%% Forward--Backward
fprintf(sprintf('performing FB...\n'));
r = 0;

p = 1;
q = 1;

[xs1,xl1, its1, ek1] = func_FISTA(para, GradF, ProxJ, p,q,r);

fprintf('\n');
%% FISTA-Mod
fprintf(sprintf('performing FISTA...\n'));

r = 4;

p = 1;
q = 1;

[xs2,xl2, its2, ek2] = func_FISTA(para, GradF, ProxJ, p,q,r);

fprintf('\n');
%% plot
linewidth = 1.5;

axesFontSize = 8;
labelFontSize = 8;
legendFontSize = 8;

resolution = 300; % output resolution
output_size = 300 *[10, 8]; % output size

%%%%%% relative error

figure(100), clf;
set(0,'DefaultAxesFontSize', axesFontSize);
set(gcf,'paperunits','centimeters','paperposition',[-0.05 -0.17 output_size/resolution]);
set(gcf,'papersize',output_size/resolution-[0.85 0.5]);

p1 = semilogy(ek1, 'r', 'LineWidth',linewidth);
hold on,

p2 = semilogy(ek2, 'k', 'LineWidth',linewidth);

grid on;
ax = gca;
ax.GridLineStyle = '--';

axis([1 length(ek1)+0 1e-10 1e2]);
ytick = [1e-10, 1e-6, 1e-2, 1e2];
set(gca, 'yTick', ytick);


ylb = ylabel({'$\|x_{k}-x_{k-1}\|$'}, 'FontSize', 10, 'FontAngle', 'normal', 'Interpreter', 'latex');
set(ylb, 'Units', 'Normalized', 'Position', [-0.1, 0.5, 0]);
xlb = xlabel({'\vspace{-1.0mm}';'$k$'}, 'FontSize', 10, 'FontAngle', 'normal', 'Interpreter', 'latex');
set(xlb, 'Units', 'Normalized', 'Position', [1/2, -0.055, 0]);

lg = legend([p1, p2], 'FB', 'FISTA');
set(lg,'FontSize', 10);
legend('boxoff');

filename = ['results', filesep, sprintf('PCP_inexact.pdf')];
print(filename, '-dpdf');
filename = ['results', filesep, sprintf('PCP_inexact.png')];
print(filename, '-dpng');