function [v1,v2, its, ek] = func_exPCP_DR(para, a)
itsprint(sprintf('        step %08d: norm(ek) = %.3e', 1,1), 1);

% parameter initialization
beta = para.beta;
mu1 = para.mu1;
mu2 = para.mu2;
maxits = para.maxits;

gamma = 1.0 *beta;
tau = mu1*gamma;
n = para.n;
f = para.f;


ek = zeros(maxits, 1);

its = 1;
ToL = 1e-14;

z1_0 = zeros(n);
z2_0 = z1_0;

proj_z1 = @(z1, z2) z1 + (f- (z1+z2)) /2;
proj_z2 = @(z1, z2) z2 + (f- (z1+z2)) /2;

z1 = z1_0;
z2 = z2_0;
z = [z1(:); z2(:)];

y1 = z1;
y2 = z2;

z1_m1 = z1; % z1_m2 = z1_m1;
z2_m1 = z2; % z2_m2 = z2_m1;
z_km1 = z;

while(its<maxits)
    
    z1_m2 = z1_m1; z1_m1 = z1; 
    z2_m2 = z2_m1; z2_m1 = z2; 
    
    z_km2 = z_km1;
    z_km1 = z;
    
    v1 = proj_z1(y1, y2);
    v2 = proj_z2(y1, y2);
    
    u1 = wthresh(2*v1-y1, 's', tau);
    u2 = svt(2*v2-y2, mu2);
    
    z1 = y1 + u1 - v1;
    z2 = y2 + u2 - v2;
    
    z = [z1(:); z2(:)];
    
    d1_1 = z1 - z1_m1; 
    d1_2 = z1_m1 - z1_m2;
    y1 = z1 + a(1)*d1_1 + a(2)*d1_2;
    
    d2_1 = z2 - z2_m1; 
    d2_2 = z2_m1 - z2_m2;
    y2 = z2 + a(1)*d2_1 + a(2)*d2_2;
    
    %%% stop?
    normE = norm(z-z_km1, 'fro');
    if mod(its,1e2)==0
        itsprint(sprintf('        step %08d: norm(ek) = %.3e', its,normE), its);
    end
    
    ek(its) = normE;
    if ((normE/prod(n))<ToL)||(normE>1e10) break; end
    
    its = its + 1;
    
end
fprintf('\n');

ek = ek(1:its-1);
